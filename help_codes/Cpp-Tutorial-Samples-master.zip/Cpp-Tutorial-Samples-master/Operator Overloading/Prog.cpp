#include "PhoneNum.h"
#include <iostream>
using namespace std;

int main ( void )
{
	PhoneNum Num1;
	cin >> Num1;
	cout << Num1 << endl;
	return 0;
}
